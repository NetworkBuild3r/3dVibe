Packed kit members for archive-tree tests.
